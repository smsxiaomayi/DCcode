function out = cEE(x, y, z, p, k, Thei)
%cEE: compute the conditional/direct embedding entropy causality from x to y condition on z, with order p.
% x: dx*T time series with T time points.
% y: dy*T time series with T time points.
% z: dz*T time series with T time points.
% p: the order of model to estimate casaulity.
% k: the k-th nearest number to use in calculating entropy, at least 2.
% Thei: half the length of Theiler correction window. [-Thei, Thei] around point i. Thei>=p.
%Use the kNN method to estimate the CMI(X, YpNN | ZpNN), where X = x_*, YpNN = dy*(p+1)+1 NN around [y_t, y_*],
% ZpNN = dz*(p+1)+1 NN around [z_t, z_*], *means t-1, t-2, ... t-p.
%kNN formular CMI(X, Y|Z) = H(X|Z) - H(X|Y, Z) = psi(k) - <psi(nXZ+1) + psi(nYZ+1) - psi(nZ+1)>.

if (nargin<4 || p<1), p = 1; end
if (nargin<5 || k<2), k = 2; end
if (nargin<6 || Thei<p), Thei = p; end

[dy, T] = size(y); dx = size(x, 1); dz = size(z, 1);

X = zeros(T-p, dx*p); % dx*p columns
for i = 1:p
    X(:, ((i-1)*dx+1):(i*dx)) = x(:, (p+1-i):(end-i))';
end

Y = zeros(T-p, dy*(p+1)); %dy*(p+1) columns
Y(:, 1:dy) = y(:, (p+1):end)';
for i = 1:p
    Y(:, (i*dy+1):((i+1)*dy)) =  y(:, (p+1-i):(end-i))'; %(T-p)*dy matrix
end

Z = zeros(T-p, dz*(p+1)); %dz*(p+1) columns
Z(:, 1:dz) = z(:, (p+1):end)';
for i = 1:p
    Z(:, (i*dz+1):((i+1)*dz)) =  z(:, (p+1-i):(end-i))'; %(T-p)*dz matrix
end

% the (dy*(p+1)+1)NN of Y_t on Manifold M_Y. the (dz*(p+1)+1)NN of Z_t on Manifold M_Z
YpNN = zeros(T-p, size(Y, 2)*(dy*(p+1)+1)); ZpNN = zeros(T-p, size(Z, 2)*(dz*(p+1)+1));
for i = 1:(T-p)
    % Theiler correction. Points around i are excluded.
    ids = max(1, i-Thei); idf = min(i+Thei, T-p); idx = ones(T-p, 1); idx(ids:idf) = 0; idx = logical(idx);
    %(dy*(p+1)+1)NN in Y_t space
    temp1 = Y(idx, :);
    [pnnidx, ~] = knnsearch(temp1, Y(i, :), 'K', dy*(p+1)+1, 'Distance', 'euclidean'); %dy*(p+1)+1th NN
    temp2 = temp1(pnnidx, :)';
    YpNN(i, :) = temp2(:)';
    %(dz*(p+1)+1)NN in Z_t space
    temp1 = Z(idx, :);
    [pnnidx, ~] = knnsearch(temp1, Z(i, :), 'K', dz*(p+1)+1, 'Distance', 'euclidean'); %dz*(p+1)+1th NN
    temp2 = temp1(pnnidx, :)';
    ZpNN(i, :) = temp2(:)';
end

%Calculate conditional mutual information of prediction
% kNN in (X, YpNN, ZpNN) space
nXZ = zeros(T-p, 1); nYZ = zeros(T-p, 1); nZ = zeros(T-p, 1);
for i = 1:(T-p)
     %Theiler correction. Points around i are excluded.
    ids = max(1, i-Thei); idf = min(i+Thei, T-p); idx = ones(T-p, 1); idx(ids:idf) = 0; idx = logical(idx);
    %kNN in (X, YpNN, ZpNN) space
    [~, D] = knnsearch([X(idx, :), YpNN(idx, :), ZpNN(idx, :)], [X(i, :), YpNN(i, :), ZpNN(i, :)], 'K', k, 'Distance', 'chebychev'); %kth NN
    halfepsilonXYZ = D(k); %the distance of kNN = epsilon/2
    nXZ(i) = sum(pdist2([X(idx, :), ZpNN(idx, :)], [X(i, :), ZpNN(i, :)], 'chebychev')<halfepsilonXYZ);
    nYZ(i) = sum(pdist2([YpNN(idx, :), ZpNN(idx, :)], [YpNN(i, :), ZpNN(i, :)], 'chebychev')<halfepsilonXYZ);
    nZ(i) = sum(pdist2(ZpNN(idx, :), ZpNN(i, :), 'chebychev')<halfepsilonXYZ);
end

%cTauDC index
idN = (nXZ~=0)&(nYZ~=0)&(nZ~=0);
out = abs(psi(k) - mean(psi(nXZ(idN)+1)) - mean(psi(nYZ(idN)+1)) + mean(psi(nZ(idN)+1)));
end
