function out = cECmy(x, y, z, p, Thei)
%cECmy: compute the conditional embedding causality from x to y condition on z, with order p.
% x: dx*T time series with T time points.
% y: dy*T time series with T time points.
% z: dz*T time series with T time points.
% p: the order of model. The embedding dimension is dy*(p+1) for Y, dx*p for X^*, and dz*p for Z^*, which should be >2*innerdimension.
% Thei: half the length of Theiler correction window. [-Thei, Thei] around point i. Thei>=p.
%cEC uses Y to predict X^* as hatX, and uses Y to predict X^* indirect through Z^* as hatXZ = X^Z^Y. *means t-1, t-2, ... t-p
% Partial cross mapping (PCM) uses rho = |partialcorr(hatX, X^*| hatXZ)| as the index

if (nargin<4 || p<2), p = 2; end
if (nargin<5 || Thei<p), Thei = p; end

[dy, T] = size(y); dx = size(x, 1); dz = size(z, 1);

X = zeros(T-p, dx*p); %dx*p columns
for i = 1:p
    X(:, ((i-1)*dx+1):(i*dx)) = x(:, (p+1-i):(end-i))'; %(T-p)*dx matrix
end

Y = zeros(T-p, dy*(p+1)); %dy*(p+1) columns
Y(:, 1:dy) = y(:, (p+1):end)';
for i = 1:p
    Y(:, (i*dy+1):((i+1)*dy)) =  y(:, (p+1-i):(end-i))'; %(T-p)*dy matrix
end

Z = zeros(T-p, dz*p); %dz*p columns
for i = 1:p
    Z(:, ((i-1)*dz+1):(i*dz)) =  z(:, (p+1-i):(end-i))'; %(T-p)*dz matrix
end

% kNN in Y space. Use dy*(p+1)+1 points in dy*(p+1) space.
hatX = zeros(size(X)); hatZ = zeros(size(Z));
for i = 1:(T-p)
    % Theiler correction. Points around i are excluded.
    ids = max(1, i-Thei); idf = min(i+Thei, T-p); idx = ones(T-p, 1); idx(ids:idf) = 0; idx = logical(idx);
    tempY = Y(idx, :); tempX = X(idx, :); tempZ = Z(idx, :);
    [idy, D] = knnsearch(tempY, Y(i, :), 'K', dy*(p+1)+1);
    U = exp(-D./D(1)); U = U./sum(U); %calculate the weight of dy*(p+1)+1 nearest neighbors.
    hatX(i, :) = sum(tempX(idy, :).*U', 1);
    hatZ(i, :) = sum(tempZ(idy, :).*U', 1);
end
% kNN in Z space. Use dz*p+1 points in dz*p space.
hatXZ = zeros(size(X));
for i = 1:(T-p)
    % Theiler correction. Points around i are excluded.
    ids = max(1, i-Thei); idf = min(i+Thei, T-p); idx = ones(T-p, 1); idx(ids:idf) = 0; idx = logical(idx);
    temphatZ = hatZ(idx, :); tempX = X(idx, :);
    [idhatz, D] = knnsearch(temphatZ, hatZ(i, :), 'K', dz*p+1);
    U = exp(-D./D(1)); U = U./sum(U); %calculate the weight of dz*p+1 nearest neighbors.
    hatXZ(i, :) = sum(tempX(idhatz, :).*U', 1);
end

%cEC index
cEC = zeros(1, size(X, 2));
for i = 1:size(X, 2)
    %partial correlation of prediction hatX and real X condition on hatXZ, for each component.
    cEC(i) = abs(partialcorr(X(:, i), hatX(:, i), hatXZ(:, i)));
end
out = mean(cEC);
end
